import { Component, OnInit } from '@angular/core';
import { ImageListService } from '../services/image-list.service';
@Component({
  selector: 'app-image-listing',
  templateUrl: './image-listing.component.html',
  styleUrls: ['./image-listing.component.css']
})
export class ImageListingComponent implements OnInit {

  list : any = [];

  compareList : any = []; 

  constructor(private imagelistService: ImageListService) { }

  ngOnInit(): void {


    this.imagelistService.getImageList().subscribe(imglist=>{
      console.log(imglist);
      imglist.forEach((element:any) => {
       if(element.albumId===1)
       {
         this.list.push(element);
       }
        
      });
      
    })
  }

  addToCompare(element:any) {

    this.compareList.push(element);

    console.log("test",this.compareList);

  }

  removeToCompare(compare:any)
  {
    console.log(compare);
  }

}
